Car Launcher (Android 13-16, minSdk 33, targetSdk 36)

Android Studio: File > Open > выбрать эту папку > дождаться Gradle Sync > Build > Build APK(s).
Без Android Studio: залить содержимое в GitHub-репозиторий -> вкладка Actions -> Build APK -> Artifacts.
